# 0x01-variables_if_else_while for learning C at Holberton School
# Max Stuart 2018-01-18 
