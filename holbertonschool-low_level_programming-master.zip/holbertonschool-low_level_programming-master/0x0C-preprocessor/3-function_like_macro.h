#ifndef h
#define h

#define ABS(x) (((x) > 0) ? (x) : (-(x)))

#endif /* h */
