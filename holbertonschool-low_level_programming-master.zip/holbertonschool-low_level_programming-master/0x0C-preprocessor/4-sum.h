#ifndef SUMh
#define SUMh

#define SUM(x, y) ((x) + (y))

#endif /* SUMh */
