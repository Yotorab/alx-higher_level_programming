#include "holberton.h"

/**
 * add - adds two integers
 * @a: integer
 * @b: integer
 *
 * Return: result of a + b
 */
int add(int a, int b)
{
	int c;

	c = a + b;
	return (c);
}
