#include "holberton.h"

/**
 * main - prints Holberton
 *
 * Return: 0 (Always)
 */
int main(void)
{
	_putchar('H');
	_putchar('o');
	_putchar('l');
	_putchar('b');
	_putchar('e');
	_putchar('r');
	_putchar('t');
	_putchar('o');
	_putchar('n');
	_putchar('\n');
	return (0);
}
