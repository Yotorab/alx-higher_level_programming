# 0x02. C - Functions, nested loops
# Max Stuart 2018-01-22