# holbertonschool-low_level_programming
# Max Stuart 2018-01-17

This repo uses submodules, to clone it use `git clone --recursive` or you might not have contents in the `/0x19-stacks_queues_lifo_fifo` (`monty`) directory. If you've already cloned just run `git submodule update`.
