##0x08-static_libraries
##Max Stuart 2018-02-09
