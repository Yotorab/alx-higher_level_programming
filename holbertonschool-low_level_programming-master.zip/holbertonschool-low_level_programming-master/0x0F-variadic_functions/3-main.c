#include "variadic_functions.h"

/**
 * main - check the code for Holberton School students.
 *
 * Return: Always 0.
 */
int main(void)
{
	print_all(NULL, "Ho", 0, "llysmokes", 223.45, 'k');
	return (0);
}
