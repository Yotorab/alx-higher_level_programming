##0x0F-variadic_functions
##Max Stuart 2018-02-23
# printf
