#include <stdio.h>

/**
 * main - prints text string to stderr
 *
 * Return: Always 1 (Error)
 */
int main(void)
{
	fprintf(stderr, "and that piece of art is useful\"");
	fprintf(stderr, " - Dora Korpar, 2015-10-19\n");
	return (1);
}
