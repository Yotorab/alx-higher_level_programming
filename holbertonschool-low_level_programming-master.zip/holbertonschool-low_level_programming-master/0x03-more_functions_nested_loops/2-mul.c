#include "holberton.h"

/**
 * mul - multiplies two integers
 * @a: integer
 * @b: integer
 *
 * Return: result of a * b
 */
int mul(int a, int b)
{
	int c;

	c = a * b;
	return (c);
}
