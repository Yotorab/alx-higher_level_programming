##0x07-recursion
##Max Stuart 2018-02-07
