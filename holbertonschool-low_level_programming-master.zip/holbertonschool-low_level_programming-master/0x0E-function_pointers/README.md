##0x0E-function_pointers
##Max Stuart 2018-02-21
