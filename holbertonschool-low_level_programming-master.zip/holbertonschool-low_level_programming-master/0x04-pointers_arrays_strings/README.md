##0x04-pointers_arrays_strings
##Max Stuart 2018-01-29
