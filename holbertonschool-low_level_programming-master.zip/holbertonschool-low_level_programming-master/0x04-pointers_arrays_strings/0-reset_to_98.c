#include "holberton.h"

/**
 * reset_to_98 - updates the value a pointer points to
 * @n: pointer to an integer
 */
void reset_to_98(int *n)
{
	*n = 98;
}
