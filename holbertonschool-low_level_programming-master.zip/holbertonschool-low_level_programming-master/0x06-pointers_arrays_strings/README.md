##0x06-pointers_arrays_strings
##Max Stuart 2018-02-05
