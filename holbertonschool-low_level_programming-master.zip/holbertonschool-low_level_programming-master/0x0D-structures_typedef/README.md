##0x0D-structures_typedef
##Max Stuart 2018-02-19
