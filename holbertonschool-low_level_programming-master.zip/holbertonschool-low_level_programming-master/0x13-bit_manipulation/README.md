# 0x13-bit_manipulation
# Max Stuart 2018-03-08
