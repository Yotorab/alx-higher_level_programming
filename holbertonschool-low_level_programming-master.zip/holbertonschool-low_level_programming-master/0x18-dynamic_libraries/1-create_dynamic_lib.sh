#!/bin/bash
cat *.c >> liball.c
gcc -fPIC -c liball.c
gcc -shared -o liball.so liball.o
