##0x05-pointers_arrays_strings
##Max Stuart 2018-02-01
